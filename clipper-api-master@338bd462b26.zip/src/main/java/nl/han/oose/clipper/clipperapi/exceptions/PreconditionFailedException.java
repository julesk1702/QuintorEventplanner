package nl.han.oose.clipper.clipperapi.exceptions;

public class PreconditionFailedException extends RuntimeException {

    public PreconditionFailedException(String message) {
        super(message);
    }

}
