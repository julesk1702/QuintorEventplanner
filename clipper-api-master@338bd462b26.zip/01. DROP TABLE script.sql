use `quintor-main`;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE diets;
DROP TABLE event_feedback;
DROP TABLE events;
DROP TABLE guest_diets;
DROP TABLE guests;
DROP TABLE ideas;
DROP TABLE registrations;
DROP TABLE user_custom_diets;
DROP TABLE user_diets;
DROP TABLE user_likes_ideas;
DROP TABLE users;
SET FOREIGN_KEY_CHECKS=1;
